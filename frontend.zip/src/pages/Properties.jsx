const Properties = () => {
    return <div>Properties Page</div>;
  };
  
  export default Properties;
  